<template>
    <view class="load-main">
        <view class="load-box">
            <view class="load-text">
                登录
            </view>
            <view class="load-input">
                <input type="text" placheholder-class="load-place" placeholder="请输入帐号" v-model="username"/>
            </view>
            <view class="load-input">
                <input type="text" password placheholder-class="load-place" placeholder="请输入密码" v-model="password"/>
            </view>
            <view class="load-button">
                <button class="load-button-style" type="warn" @tap="checklogin">登录</button>
            </view>
        </view>
    </view>
</template>

<script>
    export default {
      data() {
        return {
          username:'',
          password:'',
        }
      },
      onLoad() {
          
      },
      methods: {
        checklogin() {
            uni.request({
                url: 'http://api.joybon.net/oauth/token',
                method: 'GET',
                data: {
                    username:this.username,
                    userpassword:this.password
                },
                success: res => {
                    //console.log(res.data);
                    if(res.data.status == 'ok'){
                        uni.showToast({
                            title: '登录成功',
                            icon:'success'
                        });
                    }
                    else{
                        uni.showToast({
                            title: '用户名和密码错误',
                            icon:'none'
                        });
                    }
                },
                fail: () => {},
                complete: () => {}
            });
        }
      }
    }
</script>

<style lang="scss">
    .load-main{
        display: flex;
        justify-content: center;
        
    }
    .load-box{
        display: flex;
        width: 90%;
        height: 250px;
        flex-direction: column;
        justify-content: space-between;
        
    }
    .load-text{
        line-height: 40px;
        font-size: 25px;
    }
    
    .load-input{
        display: flex;
        border: 1px solid #cccccc;
        height: 40px;
        align-items: center;
    }
    .load-place{
        padding-left: 10px;
        font-size: 15px;
    }
    
</style>