<template>
	<view class="uni-margin-wrap">
		<swiper class="swiper" circular indicator-dots="true" autoplay="true" interval="3000" duration="500">
			<swiper-item v-for="image in imageList">
				<image class="lunb" mode="widthFix" :src="baseUrl + image.imageUrl"></image>
			</swiper-item>
		</swiper>
	</view>
	<view class="secondIx">
		<view class="secondIx1">
			<a><img src="/static/hot.png" class="image-style"></a>
			<a><img src="/static/Nougat.png" class="image-style"></a>
			<a><img src="/static/Pineapple%20Cake.png" class="image-style"></a>
			<a><img src="/static/sun%20cake.jpg" class="image-style"></a>
		</view>
		<view class="secondIx2">
			<view class="secondIx2-big">

				<img src="/static/HomeCouponBackground.png" class="coupon-background">
				<view class="secondIx2-small">
					<a><img src="/static/HomeCoupon50.png" class="coupon-img"></a>
					<a><img src="/static/HomeCoupon100.png" class="coupon-img"></a>
					<a><img src="/static/HomeCoupon150.png" class="coupon-img"></a>
				</view>
			</view>
		</view>

		<view v-for="(item,index) in bannerList1" :key="index">
			<view class="title">
				<text>{{item.market.title}}</text>
			</view>
			<view class="banner" v-if="Object.hasOwn(item,'banners')">
				<image :src="baseUrl + item.banners[0].imageUrl" mode="widthFix" class="banner-imag"></image>
			</view>
			<view class="product_list">
				<scroll-view scroll-x="true" class="scroll1">
					<view class="product" v-for="product in item.products" :key="product.id">
						<view class="product1">
							<image :src="baseUrl + getFirstImage(product.imageUrl)" mode="aspectFill" class="pro_img"></image>
							<view class="product2">
								<text class="pro_name">{{product.skuName}}</text>
								<text class="pro_price">{{product.price}}</text>
							</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</view>

		<view class="tuishop">
			<text class="product2">推荐商品</text>
			<view class="tui_flex">
				<view class="tui_left" @click="prevProduct">
					<uni-icons type="left" size="30"></uni-icons>
				</view>

				<swiper :current="curDot" @change="swiperChange" :circular="circular" class="tui_swiper"
					indicator-dots="true" autoplay="true" interval="3000" duration="5000" >
					<view v-for="(item,index) in bannerList2" :key="index">
						<view v-for="banners in item.banners" :key="banners">
							<swiper-item class="tui2">
								<image :src="baseUrl +banners.imageUrl" alt="Image" class="tui_img"></image>
								<text class="tui_name1">{{banners.title}}</text>
								<text class="tui_name2">{{banners.content}}</text>
							</swiper-item>
						</view>
					</view>
				</swiper>


				<view class="tui_right" @click="nextProduct">
					<uni-icons type="right" size="30"></uni-icons>
				</view>
			</view>

		</view>
	</view>
</template>

<script>
	import { getFirstImage } from '../../utils/image.js';
	
	export default {
		data() {
			return {
				Text: [],
				baseUrl: 'https://api.joybon.net/rest/file/image?path=',
				imageList: [],
				bannerIDList1: ['6', '1007', '1006', '74', '103', '104', '105'],
				bannerList1: [],
				bannersIDList2: ['67'],
				bannerList2: [],
				currentProductIdx:[]

			}
		},
		methods: {
			getFirstImage,
			prevProduct(){
				this.currentProductIdx = this.currentProductIdx - 1 
				if (this.currentProductIdx = -1) {
					this.currentProductIdx = this.bannerIDList1.lenth -1
				}
			},
			nextProduct(){
				this.currentProductIdx = this.currentProductIdx + 1 
				if (this.currentProductIdx = this.bannerIDList1.lenth) {
					this.currentProductIdx = 0
				}else{
					this.currentProductIdx = this.currentProductIdx + 1
				}
			}
		},
		mounted() {
			uni.request({
				url: 'https://api.joybon.net/rest/banner/place?place=1&platform=2&inside=0',
				method: "GET",
				success: (res) => {
					// console.log(res.data);

					this.text = res.data.data;
					this.imageList = res.data.data;
				}
			})


			for (let id of this.bannerIDList1) {
				let bannerUrl = `https://api.joybon.net/rest/market/composite/place?place=${id}`

				uni.request({
					url: bannerUrl,
					success: (res) => {
						// console.log(res.data.data)
						if (res.data.data != null) {
							this.bannerList1.push(res.data.data) // append
						}

					}
				})
			}
			

			uni.request({
				url: 'https://api.joybon.net/rest/banner/composite/place?place=67',
				method: "GET",
				success: (res) => {
					// console.log(res.data);

					// this.text = res.data.data;
					// this.imageList = res.data.data;
					this.bannerList2.push(res.data.data);
				}
			})
			
			
			
			
			
		}
	}
</script>

<style>
	.lunb {
		width: 750rpx;
		height: 375rpx;
	}

	.swiper {
		width: 750rpx;
		height: 375rpx;
	}

	.secondIx {
		width: 750rpx;
		/* 使用百分比或rpx以适应不同屏幕 */
		height: 500rpx;
		/* 使用rpx */
		background: linear-gradient(dodgerblue, white);
		margin: 0 auto;

		/* 防止内容溢出 */
	}

	.secondIx1 {
		display: flex;
		justify-content: space-around;
		/* 均匀分布 */
		align-items: center;
		/* 垂直居中 */
		height: 200rpx;
	}

	.image-style {
		width: 150rpx;
		height: 150rpx;
	}



	.secondIx2 {
		height: 300rpx;
		position: relative;
	}

	.secondIx2-big {
		width: 750rpx;
		/* 宽度占满父容器 */
		height: 300rpx;
		/* 高度占满可用空间 */
		background-size: cover;
		/* 背景图片覆盖整个容器 */
		background-position: center;
		/* 背景图片居中 */
		position: relative;
	}

	.coupon-background {
		width: 750rpx;
		height: 300rpx;

		/* 防止图片下方有空隙 */
	}

	.secondIx2-small {
		padding-top: 80rpx;
		/* 根据需要调整 */
		position: absolute;
		top: 1rpx;
		left: 100rpx;
		display: flex;
		justify-content: space-around;
		/* 均匀分布 */
		align-items: center;




	}

	.coupon-img {
		width: 130rpx;
		height: 130rpx;
		padding: 30rpx;
	}

	.product_list {
		height: 300rpx;
		white-space: nowrap;


	}

	.scroll1 {
		width: 100%;
	}

	.product {
		display: inline-block;
		height: 200rpx;
		margin-right: 50rpx;
	}

	.product1 {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-between;
	}

	.banner-imag {
		width: 100%;
	}

	.pro_img {
		width: 200rpx;
		height: 200rpx;

	}

	.product2 {
		width: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.pro_name,
	.pro_price {
		font-size: 25rpx;
	}

	.swiper {
		height: 300rpx;
		width: 750rpx;
	}


	.tuishop {
		width: 750rpx;
		height: 600rpx;
		position: relative;
	}
	.tui_left{
		height: 500rpx;
		width: 75rpx;
		position: absolute;
		left: 0;
		
	}
	.tui_right{
		height: 500rpx;
		width: 75rpx;
		position: absolute;
		right: 0;
	}
	.tui_flex {
		flex: 1;
	}

	.tui_flex:nth-child(1) {
		flex: 5;
	}
	

	.tui_swiper {
		height: 600rpx;
		width: 600rpx;
		white-space: nowrap;
		position: absolute;
		left: 75rpx;
	}
	.tui2{
		width: 600rpx;
		height: 500rpx;
		position: relative;
	}
	.tui_img{
		width: 400rpx;
		height: 400rpx;
		position: absolute;
		top: 50rpx;
		left: 100rpx;
	}
	.tui_name1{
		position: absolute;
		bottom: 100rpx;
		width: 500rpx;
		
	}
	.tui_name2{
		position: absolute;
		bottom: 50rpx;
		width: 100rpx;
		font-size: 25rpx;
	}
	
</style>