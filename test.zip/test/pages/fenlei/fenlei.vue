<template>
        <view class="fenlei">
            <view class="fenlei1">
                <view class="product" v-for="product in list" :key="product.id">
                    <text @click="catalogue(product.id)">{{ product.name }}</text>
                </view>
            </view>
    
            <view class="fenlei2">
                <view class="product1" v-for="product1 in list2" :key="product1.id">
                    <view class="product3">
                        <text class="text1">{{product1.name}}</text>
                    </view>
                    <view class="aaa">
                        <view v-for="product2 in product1.categories" :key="product2.id" class="product2">
    
                            <view class="image3">
                                <view class="image2">
                                    <image :src="baseUrl + product2.logo" class="image1"></image>
                                    <view v-if="!product2.logo">
                                        <image src="../../static/79B91E0F6020BC72EFCE0F9BBDCFB16B.png" class="image0"></image>
                                    </view>
                                </view>
                                <text class="text2">{{ product2.name }}</text>
                            </view>
                        </view>
                    </view>
    
    
                </view>
            </view>
    
        </view>
</template>

<script>
    
    export default {
        data() {
            return {
                baseUrl: 'https://api.joybon.net/rest/file/image?path=',
                list: [],
                list2: [],
                catalogue2: [],
            }
        },
        methods: {
            catalogue(productId) {
                if (!this.catalogue2.includes(productId)) {
                    this.catalogue2.push(productId);
                }
                uni.request({
                    url: `https://api.joybon.net/rest/category/level?id=${productId}&level=2`,
                    method: 'GET',
                    success: (res) => {
                        // console.log(res.data.data);
                        this.list2 = res.data.data;
                    }

                });
            }
        },
        mounted() {
            uni.request({
                url: 'https://api.joybon.net/rest/category/level',
                method: 'GET',
                success: (res) => {
                    this.list = res.data.data;
					console.log(res.data);
                }

            });
            
            
        }
    }
</script>


<style>
    .fenlei1 {
        position: fixed
    }

    .fenlei2 {
        width: 300px;
        margin-left: auto;
        /* display: flex; */
        /* float: right; */
    }

    .text2 {
        font-size: 10px;
        display: flex;
        justify-content: center;
    }

    .product {
        margin: 3px;
        background-color: lightgoldenrodyellow;
        width: 70px;
        height: 28px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .aaa {
        display: flex;
        flex-wrap: wrap;

    }

    image[src="https://api.joybon.net/rest/file/image?path=undefined"],
    image:not([src]) {
        display: none;
    }

    .product2 {
        height: 130px;
        width: 90px;

    }


    .image1 {
        margin-top: 10px;
    }

    .image0 {
        width: 90px;
        height: 90px;
        margin-top: 10px;
        /* position: absolute; */
    }

    .image1 {
        width: 90px;
        height: 90px;
    }




    .fenlei {
        display: flex;

    }
</style>