function getFirstImage(imageUrl){
	let imageList1 = imageUrl.split(",")
	return imageList1[0]
}

export {getFirstImage}